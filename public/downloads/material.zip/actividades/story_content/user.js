function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5zveSVl5DR9":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

